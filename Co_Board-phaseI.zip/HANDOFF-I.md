# HANDOFF — Co_Board פאזה I (פיצ'רים) — חבילה נפרדת

חבילה זו מוסיפה את **פאזה I** (פיצ'רים חדשים) מעל בסיס A–H.
**החל אותה אחרי** שהחלת ומיזגת את חבילת A–H (`Co_Board-changes.zip`).

> ⚠️ **לא הורץ אצלי** (אין רשת/התקנת חבילות). הקוד נכתב עם אימות-טיפוסים ידני קפדני.
> **חובה להריץ אימות** (סעיף 3) ולתקן אם משהו אדום לפני commit/push.

> כל תוספות ה-UI **אדיטיביות ומאחורי דגלים בהגדרות (כבויים כברירת מחדל)** — האפליקציה
> הקיימת אינה משתנה עד שמפעילים אותן. לכן הסיכון לרגרסיה נמוך.

---

## 0. החלה (אחרי A–H)

```bash
REPO=$(pwd)                              # שורש ה-repo
CHANGES=/path/to/Co_Board-phaseI        # תיקיית החבילה המחולצת
git checkout -b feat/phase-i            # או המשך על הענף של A–H
rsync -av --exclude='HANDOFF-I.md' "$CHANGES"/ "$REPO"/
```

7 הקבצים המשותפים (App.tsx, index.css, models.ts, accessSettings.ts, BoardView.tsx,
CellEditor.tsx, AccessSettingsPanel.tsx) הם הגרסה **הסופית (A–H + I)** — הם דורסים את
גרסת A–H בצורה נקייה (סופרסט; שום עבודת A–H לא הולכת לאיבוד).

---

## 1. קבצים (24)

### חדשים — מנועים טהורים + בדיקות
| קובץ | פאזה |
|---|---|
| `app/src/domain/morphology/hebrewMorphology.ts` (+`.test.ts`) | I1 ⭐ |
| `app/src/domain/prediction/predictor.ts` (+`.test.ts`) | I2 |
| `app/src/data/predictionRepo.ts` | I2 |
| `app/src/domain/scanning/scanEngine.ts` (+`.test.ts`) | I3 |
| `app/src/domain/growingVocab.ts` (+`.test.ts`) | I4 |
| `app/src/domain/behaviorBoards.ts` (+`.test.ts`) | I6 |
| `app/src/services/ai/boardGenerator.ts` (+`.test.ts`) | I8 |

### חדשים — רכיבי UI / hooks
| קובץ | פאזה |
|---|---|
| `app/src/services/access/useScanning.ts` | I3 |
| `app/src/presentation/components/PredictionBar.tsx` | I2 |
| `app/src/presentation/components/SceneView.tsx` | I7 |
| `app/src/presentation/components/VisualTimer.tsx` | I6 |

### מוחלפים (סופי A–H + I)
| קובץ | תוספות I |
|---|---|
| `app/src/domain/models.ts` | morphology/level (I1/I4), CellAction מורחב (I5), scene (I7) |
| `app/src/domain/accessSettings.ts` | דגלי סריקה/ניבוי/גודל-תא |
| `app/src/presentation/components/BoardView.tsx` | סינון רמה (I4) + הדגשת סריקה (I3) |
| `app/src/presentation/builder/CellEditor.tsx` | ACTION_LABELS תואם ל-CellAction מורחב (I5) |
| `app/src/presentation/settings/AccessSettingsPanel.tsx` | סקשן "סריקה וניבוי" + גודל תא |
| `app/src/App.tsx` | חיווט I2/I3/I4/I5/I7, גודל-תא I9, הדפסה I13 |
| `app/src/index.css` | סגנונות ניבוי/רמה/סריקה/סצנה/טיימר/הדפסה |

---

## 2. מה כוללת פאזה I בחבילה זו

- **I1 — מורפולוגיה עברית ⭐**: מנוע הטיות (ריבוי/יידוע/תחיליות/בינוני) + חיווט פעולת
  `modifyWord` ב-onCell ("תאי הטיה" שמשנים את המילה האחרונה במשפט).
- **I2 — ניבוי**: מנוע n-gram + `predictionRepo` (למידה מקומית בעת הקראת משפט) +
  `PredictionBar` (דגל `predictionEnabled`).
- **I3 — סריקת מתגים**: `scanEngine` + `useScanning` (אוטו/ידני, שמיעתי) + הדגשה ב-BoardView
  (דגל `scanningEnabled`, Enter/Space בוחר).
- **I4 — אוצר צומח**: `Cell.level` + סינון `visiblePlacements` ב-BoardView + בקרת רמה ב-App
  (חשיפה בלי הזזה; מוצג רק בלוחות עם רמות).
- **I5 — פעולות תא מורחבות**: `playAudio` / `playVideo` / `openLink` / `insertPrediction` /
  `modifyWord` מחווטים ב-onCell.
- **I6 — לוחות התנהגות**: מחוללי `First-Then`/לו"ז + רכיב `VisualTimer`.
- **I7 — לוחות סצנה (VSD)**: `Board.kind='scene'` + `SceneView` (רקע + hotspots) מחווט ב-App.
- **I8 — מחולל לוח AI**: `boardGenerator` (אורקסטרציה טהורה; ה-LLM מוזרק — opt-in, ללא נתוני ילד).
- **I9 — גודל תא ≥44px**: סליידר בהגדרות → משתנה `--cell-min`.
- **I13 — הדפסת לוח**: כפתור 🖨 (מצב מבוגר) + `@media print`.

**לא בוצע במלואו:** עורך ה-hotspots ל-I7 ב-Builder, פאנל ה-prompt ל-I8 ב-Builder (המנוע
מוכן — צריך לחבר ספק LLM ו-UI), ו-I10–I12 (שיתוף OBZ/שחזור/מילון הגייה/פורטל מטפל מרחוק)
ממנפים תשתית קיימת (`obf/`, `backupRepo`, `tts/`, `portal/`) ודורשים עבודת UI נוספת.

---

## 3. אימות (חובה — לפני commit)

```bash
cd app
npm install
npm run typecheck
npm run lint
npm test            # כולל בדיקות I: morphology, predictor, scanEngine, growingVocab, behaviorBoards, boardGenerator
npm run build
```

בדיקות ידניות (הפעל את הדגלים בהגדרות → גישה):
- **ניבוי**: הפעל "ניבוי מילה הבאה" → שורת הצעות מעל הלוח; בחירה מוסיפה מילה; לומד אחרי "דבר".
- **סריקה**: הפעל "סריקת מתגים" → הדגשה עוברת; Enter/מתג בוחר; "סריקה שמיעתית" מקריא.
- **רמות**: בלוח עם `level` על תאים → בקרת רמה −/+ חושפת בלי להזיז.
- **גודל תא**: סליידר "גודל תא מינימלי" משנה את גודל התאים.
- **הדפסה**: כפתור 🖨 במצב מבוגר → תצוגת הדפסה נקייה (ללא סרגלים).

---

## 4. Commit מוצע (אחרי שהכל ירוק)

```bash
git add app/src/domain/morphology/ app/src/domain/prediction/ app/src/data/predictionRepo.ts \
        app/src/domain/scanning/ app/src/domain/growingVocab.ts app/src/domain/growingVocab.test.ts \
        app/src/domain/behaviorBoards.ts app/src/domain/behaviorBoards.test.ts \
        app/src/services/access/useScanning.ts app/src/services/ai/ \
        app/src/presentation/components/PredictionBar.tsx app/src/presentation/components/SceneView.tsx \
        app/src/presentation/components/VisualTimer.tsx \
        app/src/domain/models.ts app/src/domain/accessSettings.ts \
        app/src/presentation/components/BoardView.tsx app/src/presentation/builder/CellEditor.tsx \
        app/src/presentation/settings/AccessSettingsPanel.tsx app/src/App.tsx app/src/index.css
git commit -m "feat(phase-i): Hebrew morphology, prediction, switch scanning, growing vocab, behavior/scene boards, AI generator, print"
git push -u origin feat/phase-i
```

(אם ה-repo לא מחובר ל-remote — עצור ושאל לפני push.)
