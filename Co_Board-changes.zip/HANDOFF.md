# HANDOFF — Co_Board תיקוני פאזות A–H + ליבת פאזה I

מטרה: להחיל את חבילת הקבצים על ה-repo, לחלק ל-commits לפי פאזה, לאמת, ולדחוף.
**אין צורך לחשוב — רק לבצע.** כל הקבצים בחבילה הם המצב הסופי (כל הפאזות ממוזגות).

> ⚠️ **לא הורץ אצלי:** הסביבה שבה נוצרה החבילה היא ללא רשת והתקנת חבילות חסומה
> (`node_modules` לא קיים). לכן `npm install/build/test` **לא רצו**. הקוד נכתב עם
> אימות-טיפוסים ידני קפדני. **חובה להריץ את שלב האימות למטה** ולתקן אם משהו אדום.

> **פאזה I:** מומשה **ליבת המנועים** (I1–I6) כמודולי domain/services טהורים + בדיקות,
> אדיטיביים לחלוטין (לא נוגעים בקוד קיים). I7 (VSD), I8 (AI, דורש endpoint LLM) ו-I9–I13,
> וכן חיווט תאי הניבוי/סריקה/הטיה ל-UI — **לא בוצעו** (מומלץ לבצע עם build חי).

---

## 0. החלת הקבצים על ה-repo

```bash
REPO=$(pwd)                              # שורש ה-repo (היכן ש-app/ ו-functions/)
CHANGES=/path/to/Co_Board-changes       # תיקיית החבילה המחולצת
git checkout -b fix/phases-a-i
rsync -av --exclude='HANDOFF.md' "$CHANGES"/ "$REPO"/
```

---

## 1. טבלת קבצים → יעד ב-repo (64 קבצים: 42 שונו, 22 חדשים)

### A–H (כמו קודם — תקציר)
| קובץ | סטטוס | פאזות |
|---|---|---|
| `app/src/data/syncMeta.ts` | חדש | A1 |
| `app/src/data/boardRepo.ts` · `profileRepo.ts` | מוחלף | A1 |
| `app/src/services/sync/syncEngine.ts` | מוחלף | A1, C2 |
| `app/src/services/access/dwellService.ts` (+`.test.ts`) | מוחלף | A2 |
| `app/src/services/tts/ttsService.ts` | מוחלף | A3, A4, A6 |
| `app/src/services/tts/hybridTtsService.ts` | מוחלף | A6 |
| `app/src/services/tts/speakCell.a4.test.ts` | חדש | H2/A4 |
| `app/src/domain/models.ts` | מוחלף | A4, **I1, I4, I5** |
| `app/src/services/sync/crypto.ts` | מוחלף | B1, B2, E3 |
| `app/src/data/keyStore.ts` · `firebaseEnv.ts` | חדש | B1 / G2 |
| `app/src/data/db.ts` | מוחלף | B1 (v11) |
| `app/src/data/childRepo.ts` (+`.test.ts`) | מוחלף/חדש | A5, B3, G2 / H2 |
| `docs/firestore.rules` · `firebase/storage.rules` | מוחלף | B3, B4 |
| `functions/src/acceptInvite.ts` | חדש | B3 |
| `functions/src/approveUser.ts` · `index.ts` · `package.json` | מוחלף | B3, B4, H1 |
| `functions/test/rules.test.ts` | חדש | B4/H1 |
| `firebase.json` | מוחלף | B5 |
| `app/src/data/settingsRepo.ts` | מוחלף | C2 |
| `app/src/presentation/ui/useFocusTrap.ts` · `Modal.test.tsx` | חדש | D1 |
| `app/src/presentation/ui/Modal.tsx` · `builder/SymbolPicker.tsx` | מוחלף | D1 |
| `app/src/presentation/ui/ErrorBoundary.tsx` | חדש | D2 |
| `app/src/main.tsx` | מוחלף | D2 |
| `app/src/services/analytics/analyticsService.ts` · `data/backupRepo.ts` · `data/mediaRepo.ts` | מוחלף | D3 |
| `app/src/presentation/components/BoardView.tsx` · `CellButton.tsx` (+`.test.tsx`) | מוחלף | E1, E2, F1 |
| `app/vite.config.ts` | מוחלף | E3 |
| `app/src/index.css` | מוחלף | D2, F1–F6 |
| `app/src/domain/accessSettings.ts` · `settings/AccessSettingsPanel.tsx` | מוחלף | F4 |
| `app/src/presentation/components/BrandBar.tsx` · `SentenceBar.tsx` | מוחלף | F3/F5 · F6 |
| `app/src/presentation/builder/CellEditor.tsx` | מוחלף | A4, D1, F5, G1, **I5** |
| `app/src/presentation/builder/BuilderView.tsx` | מוחלף | F5, G1 |
| `app/src/services/nikud/nakdanClient.ts` · `services/sync/firebaseProvider.ts` | מוחלף | G2 |
| `app/src/App.tsx` (+`App.test.tsx`) | מוחלף | A3/C1/D3/E1-3/F3-4 |
| `.github/workflows/ci.yml` · `app/package.json` | מוחלף | H1 |
| `app/src/services/sync/sync.test.ts` · `crypto.test.ts` | מוחלף/חדש | H2 |

### I (חדש — ליבת מנועים טהורה)
| קובץ | סטטוס | פאזה |
|---|---|---|
| `app/src/domain/morphology/hebrewMorphology.ts` (+`.test.ts`) | חדש | I1 ⭐ |
| `app/src/domain/prediction/predictor.ts` (+`.test.ts`) | חדש | I2 |
| `app/src/data/predictionRepo.ts` | חדש | I2 |
| `app/src/domain/scanning/scanEngine.ts` (+`.test.ts`) | חדש | I3 |
| `app/src/domain/growingVocab.ts` (+`.test.ts`) | חדש | I4 |
| `app/src/domain/behaviorBoards.ts` (+`.test.ts`) | חדש | I6 |

> `models.ts` ו-`CellEditor.tsx` נושאים גם שינויי I (מסומן למעלה) — הם מתחייבים ב-commit
> של הפאזה המוקדמת שלהם (A / G), והשינוי האדיטיבי של I נכלל שם.

---

## 2. Commits לפי פאזה (כל קובץ פעם אחת)

```bash
# A
git add app/src/data/syncMeta.ts app/src/data/boardRepo.ts app/src/data/profileRepo.ts \
        app/src/services/sync/syncEngine.ts app/src/services/access/dwellService.ts \
        app/src/services/access/dwellService.test.ts app/src/services/tts/ttsService.ts \
        app/src/services/tts/hybridTtsService.ts app/src/domain/models.ts
git commit -m "fix(core): outbox+LWW wiring, dwell jitter, TTS init/cancel, audio mimeType/audioId (phase A; models also I1/I4/I5)"

# B
git add app/src/services/sync/crypto.ts app/src/data/keyStore.ts app/src/data/db.ts \
        app/src/data/firebaseEnv.ts app/src/data/childRepo.ts docs/firestore.rules \
        firebase/storage.rules functions/src/acceptInvite.ts functions/src/approveUser.ts \
        functions/src/index.ts functions/package.json firebase.json
git commit -m "security: non-extractable key, device-wrapped media CEK, one-time share codes, rules+CSP (phase B; childRepo also A5/G2)"

# C
git add app/src/data/settingsRepo.ts
git commit -m "perf(sync): persist lastSyncAt for incremental pull (phase C2)"

# D
git add app/src/presentation/ui/useFocusTrap.ts app/src/presentation/ui/Modal.tsx \
        app/src/presentation/ui/Modal.test.tsx app/src/presentation/builder/SymbolPicker.tsx \
        app/src/presentation/ui/ErrorBoundary.tsx app/src/main.tsx \
        app/src/services/analytics/analyticsService.ts app/src/data/backupRepo.ts app/src/data/mediaRepo.ts
git commit -m "feat(a11y/reliability): Modal focus-trap+Escape+restore, ErrorBoundary, prune caps (phase D)"

# E
git add app/src/presentation/components/BoardView.tsx app/src/presentation/components/CellButton.tsx \
        app/src/presentation/components/CellButton.test.tsx app/vite.config.ts
git commit -m "perf: memoize BoardView/CellButton, batch nikud, runtime-cache symbols (phase E)"

# F
git add app/src/index.css app/src/domain/accessSettings.ts \
        app/src/presentation/settings/AccessSettingsPanel.tsx \
        app/src/presentation/components/BrandBar.tsx app/src/presentation/components/SentenceBar.tsx
git commit -m "a11y: cell contrast, dark/high-contrast tokens, landmarks, keyboard, RTL cleanup (phase F)"

# G
git add app/src/presentation/builder/CellEditor.tsx app/src/presentation/builder/BuilderView.tsx \
        app/src/services/nikud/nakdanClient.ts app/src/services/sync/firebaseProvider.ts
git commit -m "fix(builder): real crop dims, reactive undo, keyboard tiles; configurable nakdan + env validation (phase G1/G2; CellEditor also A4/D1/F5/I5)"

# App (חוצת-פאזות)
git add app/src/App.tsx app/src/App.test.tsx
git commit -m "refactor(app): sync triggers, lazy panels, <main> landmark, high-contrast theme, stable onCell, cleanup (A3/C1/D3/E1-3/F3-4)"

# H
git add .github/workflows/ci.yml app/package.json app/src/services/sync/sync.test.ts \
        app/src/services/sync/crypto.test.ts app/src/data/childRepo.test.ts \
        app/src/services/tts/speakCell.a4.test.ts functions/test/rules.test.ts
git commit -m "ci+test: enforce typecheck/lint/test + Firestore rules CI; cover sync/crypto/childRepo/audio (phase H)"

# I — ליבת מנועים (טהור + בדיקות)
git add app/src/domain/morphology/ app/src/domain/prediction/ app/src/data/predictionRepo.ts \
        app/src/domain/scanning/ app/src/domain/growingVocab.ts app/src/domain/growingVocab.test.ts \
        app/src/domain/behaviorBoards.ts app/src/domain/behaviorBoards.test.ts
git commit -m "feat(lang/access): Hebrew morphology engine, next-word prediction, switch scanning, growing vocab, behavior boards (phase I1-I6 engines)"

git push -u origin fix/phases-a-i
```

> commit יחיד: `git add -A && git commit -m "fix: phases A-H + Phase I engines"`.

---

## 3. אימות (חובה — הרץ ותקן עד ירוק)

```bash
cd app
npm install
npm run typecheck
npm run lint
npm test
npm run build
# כללי Firestore (דורש Java + firebase-tools):
cd ../functions && npm install && npm run test:rules
```

אם `crypto.test.ts` מדלג (skip) — תקין (jsdom ללא subtle מלא). בדיקות I (morphology/predictor/
scanEngine/growingVocab/behaviorBoards) הן טהורות וצריכות לעבור ללא תלות חיצונית.

### בדיקות ידניות (UI)
1. לחיצת תא מדברת מיד (A3) · 2. סנכרון דוחף תוך ~3ש' (A1/C1) · 3. מצב כהה קריא (F1/F2) ·
4. Escape סוגר מודאל + פוקוס חוזר (D1) · 5. ניגודיות גבוהה שומרת גוונים (F4) · 6. הקלטה מתנגנת (A4/A6).

---

## 4. בדיקות שעודכנו ולמה
| בדיקה | שינוי | סיבה |
|---|---|---|
| `services/access/dwellService.test.ts` | +2 בדיקות (רעד/תזוזה) | A2 |
| `components/CellButton.test.tsx` | `onActivate`→`onCell` | E1 (שם prop) |
| `App.test.tsx` | `getByLabelText`→`await findByLabelText` (Wizard) | E3 (lazy) |
| `services/sync/sync.test.ts` | +outbox-via-repo +LWW | H2/A1 |
| חדשות: `crypto.test.ts`, `childRepo.test.ts`, `speakCell.a4.test.ts`, `Modal.test.tsx` | — | H2/D1 |
| חדשות I: `hebrewMorphology.test.ts`, `predictor.test.ts`, `scanEngine.test.ts`, `growingVocab.test.ts`, `behaviorBoards.test.ts` | — | I1-I6 |

---

## 5. אם משהו אדום
- `db.ts` → `DB_VERSION = 11` (store `cryptoKeys`); אם בדיקת מיגרציה מצפה ל-10 — עדכן ל-11 (אדיטיבי).
- `crypto.test.ts` נכשל (לא מדלג) → ודא Node ≥ 18 (subtle + Blob.arrayBuffer).
- `functions` rules-tests → דורש `npm install` + אמולטור Firestore + Java.
- eslint: כל הכללים החדשים `warn` (לא מפילים אלא אם הוגדר `--max-warnings 0`).

**לא בוצעו:** G3 (ריפקטור App), I7 (VSD), I8 (AI board — דורש endpoint LLM), I9–I13,
וחיווט תאי ניבוי/סריקה/הטיה ל-App/BoardView. ה-CellAction המורחב (I5) קיים אך טרם מחווט ל-onCell.
